export interface RegisterForm{
    nombre: string,
     email: string,
     password: string,
     terminos: boolean
 }